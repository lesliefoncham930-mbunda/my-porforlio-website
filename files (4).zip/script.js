/* ── Theme Toggle ── */
    const html       = document.documentElement;
    const toggle     = document.getElementById('theme-toggle');
    const themeIcon  = document.getElementById('theme-icon');
    const themeText  = document.getElementById('theme-text');

    function setTheme(t) {
      html.setAttribute('data-theme', t);
      localStorage.setItem('theme', t);
      if (t === 'light') {
        themeIcon.textContent = '🌙';
        themeText.textContent = 'Dark';
      } else {
        themeIcon.textContent = '☀️';
        themeText.textContent = 'Light';
      }
    }

    const saved = localStorage.getItem('theme') || 'dark';
    setTheme(saved);
    toggle.addEventListener('click', () => {
      setTheme(html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });

    /* ── Scroll Reveal ── */
    const observer = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

    /* ── Nav active on scroll ── */
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-links a');
    window.addEventListener('scroll', () => {
      let cur = '';
      sections.forEach(s => {
        if (window.scrollY >= s.offsetTop - 120) cur = s.id;
      });
      navLinks.forEach(a => {
        a.style.color = a.getAttribute('href') === '#' + cur ? 'var(--accent)' : '';
      });
    });

    /* ── Contact Form ── */
    document.getElementById('contact-form').addEventListener('submit', function(e) {
      e.preventDefault();
      const notify = document.getElementById('notify');
      notify.classList.add('show');
      this.reset();
      setTimeout(() => notify.classList.remove('show'), 3500);
    });

    /* ── Parallax orbs ── */
    window.addEventListener('mousemove', e => {
      const x = (e.clientX / window.innerWidth - 0.5) * 20;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      document.querySelectorAll('.hero-bg-orb').forEach((o, i) => {
        const factor = i === 0 ? 1 : -0.6;
        o.style.transform = `translate(${x * factor}px, ${y * factor}px)`;
      });
    });